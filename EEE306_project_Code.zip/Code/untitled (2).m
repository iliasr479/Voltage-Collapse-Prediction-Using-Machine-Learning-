% Load dataset
dataset = readtable('Book1.csv');

% Data quality and preparation
% Replace missing values with suitable alternatives
% For numeric columns, replace missing values with the mean of each column
dataset = fillmissing(dataset, 'mean');


% Split dataset into features (X) and target variable (y)
X = dataset{:, 1:6};
y = dataset{:, 8};

% Split dataset into train and test sets
rng(42); % Set random seed for reproducibility
[X_train, X_test, y_train, y_test] = split_data(X, y, 0.8);

% Standardize features
scaler = fit_scaler(X_train);
X_train_scaled = transform_data(scaler, X_train);
X_test_scaled = transform_data(scaler, X_test);



% Main code
% Load dataset, preprocess, split data, standardize features
% Define model (XGBoost), hyperparameter tuning, train model,
% evaluate model (calculate R-squared), and print results

% Define hyperparameters for XGBoost
params = struct();
params.learning_rate = 0.1;
params.max_depth = 3;
params.min_child_weight = 1;
params.subsample = 1;
params.colsample_bytree = 1;
params.n_estimators = 100;

% Define XGBoost model
model = fit_xgboost_model(X_train_scaled, y_train, params);

% Evaluate model on test set
y_pred = predict(model, X_test_scaled);

% Calculate R-squared score
r_squared = calculate_r_squared(y_test, y_pred);
fprintf('R-squared: %.4f\n', r_squared);

% Function to fit XGBoost model
function model = fit_xgboost_model(X_train, y_train, params)
    model = xgb.XGBRegressor();
    model.learning_rate = params.learning_rate;
    model.max_depth = params.max_depth;
    model.min_child_weight = params.min_child_weight;
    model.subsample = params.subsample;
    model.colsample_bytree = params.colsample_bytree;
    model.n_estimators = params.n_estimators;
    model.fit(X_train, y_train);
end

% Function to calculate R-squared score
function r_squared = calculate_r_squared(y_true, y_pred)
    SSres = sum((y_true - y_pred).^2);
    SStot = sum((y_true - mean(y_true)).^2);
    r_squared = 1 - (SSres / SStot);
end

% Define binary switching function
function sigma = binary_switching_function(delta, delta_c)
    sigma = delta < delta_c;
end

% Define NLSI_1 calculation function
function nlsi_1 = calculate_nlsi_1(Q, V, Z, X, sigma, delta, delta_c)
    x = sqrt(Z.^2 - X.^2);
    term1 = (4 * Q ./ V.^2) .* ((Z.^2 ./ X) .* sigma - (x ./ sin(sigma - 1)).^2) .* (sigma - 1);
    term2 = binary_switching_function(delta, delta_c);
    nlsi_1 = term1 .* term2;
end

% Split data function
function [X_train, X_test, y_train, y_test] = split_data(X, y, test_size)
    idx = randperm(size(X, 1));
    train_size = floor((1 - test_size) * length(idx));
    X_train = X(idx(1:train_size), :);
    X_test = X(idx(train_size + 1:end), :);
    y_train = y(idx(1:train_size));
    y_test = y(idx(train_size + 1:end));
end

% Fit scaler function
function scaler = fit_scaler(X_train)
    scaler = fit_standard_scaler(X_train);
end

% Transform data function
function X_scaled = transform_data(scaler, X)
    X_scaled = transform_standard_scaler(scaler, X);
end

% Standard scaler fitting function
function scaler = fit_standard_scaler(X_train)
    scaler.mean = mean(X_train);
    scaler.std = std(X_train);
end

% Standard scaler transformation function
function X_scaled = transform_standard_scaler(scaler, X)
    X_scaled = (X - scaler.mean) ./ scaler.std;
end
