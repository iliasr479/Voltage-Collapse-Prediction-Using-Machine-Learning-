% Problem 1: 
% Baseband BW of the signal is 200 Hz. 
% Code: 
clc; 
clear all; 
close all; 
to=0.1; 
bw=200; 
fs1=2.5*bw; 
fs2=1.25*bw; 
% for fs1 
ts1=1/fs1; 
nup=round(to/ts1); 
nlo=-nup;% generate time index 
n=nlo:nup; 
t=n*ts1; 
m=(sinc(200*t)).^2; 
N=1024;% FFT bin size ,after zero padding 
fn = (0:1/N:5-1/N)*fs1-5*fs1/2; 
k=0:5*N-1; 
WN=exp(-1i*2*pi/N); 
nk=n'*k; 
W=WN.^nk; 
M=m*W; 
%M=fft(m,1024); 
figure(1) 
subplot(211),plot(fn,abs(fftshift(M)),0,0),title('For  2.5BW'),xlabel('t'),ylabel('spectra') 
%for fs2 
ts1=1/fs2; 
nup=round(to/ts1); 
nlo=-nup;% generate time index 
n=nlo:nup; 
t=n*ts1; 
m=(sinc(200*t)).^2;
N=1024;% FFT bin size ,after zero padding 
fn = (0:1/N:5-1/N)*fs2-5*fs2/2; 
k=0:5*N-1; 
WN=exp(-1i*2*pi/N); 
nk=n'*k; 
W=WN.^nk; 
M=m*W; 
%M=fft(m,1024); 
subplot(212),plot(fn,abs(fftshift(M)),0,0),title('For  1.25BW'),xlabel('t'),ylabel('spectra')