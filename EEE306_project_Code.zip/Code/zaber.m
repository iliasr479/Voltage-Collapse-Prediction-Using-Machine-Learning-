clc; 
clear all; 
close all;
fs = 8000;
N= fs/100; 
ts = 1/fs; 
t = (0:N-1)*ts; 
f = (0:N-1)*fs/N - fs/2; 
x = sin(1200*pi*t)+0.25*sin(2400*pi*t)+0.1*sin(3000*pi*t); 
 
% N = length(x); 
f1 = 600; 
f2 = 1200; 
f3 = 1500; 
ftst = gcd(gcd(f1,f2),gcd(f1,f3)) 

subplot(211),stem(t,x) 
xlabel('Time(s)'),ylabel('x[n]') 
subplot(212),stem(f,abs(fftshift(fft(x)))) 
xlabel('Frequency(Hz)'),ylabel('|X|'),title('N=80') 
hold on 
figure 
N2 = 2*N; 
t2 = (0:N-1)*ts; 
f = (0:N-1)*fs/N - fs/2; 

subplot(211),stem(t2,x) 
xlabel('Time(s)'),ylabel('x[n]') 
subplot(212),stem(f,abs(fftshift(fft(x)))) 
xlabel('Frequency(Hz)'),ylabel('|X|'),title('N=160')