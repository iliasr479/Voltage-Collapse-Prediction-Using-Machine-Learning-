clc; 
clear all; 
close all; 
x = @(t)  
sin(1200*pi*t)+0.25*sin(2400*pi*t)+ 0.1*sin(3000*pi*t); 
fs = 8000; 
% N = length(x); 
f1 = 600; 
f2 = 1200; 
f3 = 1500; 
ftst = gcd(gcd(f1,f2),gcd(f1,f3))
N = fs/100; 
ts = 1/fs; 
t = (0:N-1)*ts; 
f = (0:N-1)*fs/N - fs/2; 
subplot(211),stem(t,x(t)) 
xlabel('Time(s)'),ylabel('x[n]') 
subplot(212),stem(f,abs(fftshift(fft(x(t))))) 
xlabel('Frequency(Hz)'),ylabel('|X|'),title('N=80') 
hold on 
figure 
N = 2*N; 
t = (0:N-1)*ts; 
f = (0:N-1)*fs/N - fs/2; 
subplot(211),stem(t,x(t)) 
xlabel('Time(s)'),ylabel('x[n]') 
subplot(212),stem(f,abs(fftshift(fft(x(t))))) 
xlabel('Frequency(Hz)'),ylabel('|X|'),title('N=160')